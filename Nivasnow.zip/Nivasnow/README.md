# Hotel-booking-managment
This website is written in .html and it is of hotel booking managment system
