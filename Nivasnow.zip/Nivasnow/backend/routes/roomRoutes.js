const express = require('express');
const router = express.Router();
const AvailableRooms = require('../models/AvailableRooms');

router.get('/', async (req, res) => {
    try {
        const rooms = await AvailableRooms.find();
        res.status(200).json(rooms);
    } catch (error) {
        res.status(500).send(error);
    }
});

router.put('/:id', async (req, res) => {
    try {
        const room = await AvailableRooms.findById(req.params.id);
        if (room) {
            room.bookedRooms = req.body.bookedRooms;
            await room.save();
            res.status(200).send({ message: 'Rooms updated', room });
        } else {
            res.status(404).send({ message: 'Room not found' });
        }
    } catch (error) {
        res.status(500).send(error);
    }
});

module.exports = router;
