const mongoose = require('mongoose');

const availableRoomsSchema = new mongoose.Schema({
    roomType: String,
    totalRooms: Number,
    bookedRooms: Number
});

module.exports = mongoose.model('AvailableRooms', availableRoomsSchema);
